module.exports = {
  "peerjs": {
    "key": ""
  }
};