var express = require('express');
var router = express.Router();

var Call = require('./call');

// Create a new Call instance, and redirect
router.get('/new/:name', function(req, res) {
  var call = Call.create(req.param('name'));
  res.redirect('/' + call.id);
});
router.get('/audio/', function(req, res) {
  var call = Call.create("audio");
  res.redirect('/a/' + call.id);
});
router.post('/:id/addcall/:callurl', function(req, res) {
  var call = Call.get(req.param('id'));
  if (!call) return res.status(404).send('Call not found');
  call.stradd(req.param('callurl'));
  console.log("adding: "+req.param('callurl'));
  res.json(call.toJSON());
});
// Add PeerJS ID to Call instance when someone opens the page
router.post('/:id/addpeer/:peerid', function(req, res) {
  var call = Call.get(req.param('id'));
  if (!call) return res.status(404).send('Call not found');
  call.addPeer(req.param('peerid'));
  res.json(call.toJSON());
});

// Remove PeerJS ID when someone leaves the page
router.post('/:id/removepeer/:peerid', function(req, res) {
  var call = Call.get(req.param('id'));
  if (!call) return res.status(404).send('Call not found');
  call.removePeer(req.param('peerid'));
  res.json(call.toJSON());
});

// Return JSON representation of a Call
router.get('/:id.json', function(req, res) {
  var call = Call.get(req.param('id'));
  if (!call) return res.status(404).send('Call not found');
  res.json(call.toJSON());
});
router.get('/a/:id', function(req, res) {
  var call = Call.get(req.param('id'));
  if (!call) return res.redirect('/');
  res.render('callau', {
    call: call.toJSON()
  });
});
// Render call page
router.get('/:id', function(req, res) {
  var call = Call.get(req.param('id'));
  if (!call) return res.redirect('/');
  res.render('call', {
    call: call.toJSON()
  });
});

// Landing page
router.get('/', function(req, res) {
  var fct = Call.getAll();
  var tcar=[];
  var tnma=[];
  var pos=0;
  console.log(fct);
if(fct!=""){
  fct.forEach(function(call){
    tnma[pos] = call.name+" : "+call.peers.length+" call views";
    tcar[pos] = call.id;
    pos++;
  });
  res.render('index',{
    carray:tcar.toString(),
    cnmarr:tnma.toString()
  });
}else{
  res.render('index',{
    carray:"",
    cnmarr:"no calls at the time, please make your own."
  });
}
});

module.exports = router;